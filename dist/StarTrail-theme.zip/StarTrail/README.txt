Star Trail theme for Wave Launcher

Drop this zip into Settings > Appearance > Import theme.

Format:
  theme.json            colours, clock style, icon treatment
  icons/<package>.png   optional per-app icons, e.g. com.brave.browser.png
  fonts/clock.ttf       optional, also apps.ttf and ui.ttf

Colours accept #RRGGBB or #AARRGGBB.
Clock styles: thin, serif, mono, bold, condensed.
Set icons.desaturate true for a monochrome set.
